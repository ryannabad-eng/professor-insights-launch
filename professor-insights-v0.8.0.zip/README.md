# Professor Insights

A dependency-free Manifest V3 Chrome extension based on the supplied Figma reference. Clicking the toolbar icon opens a review panel and detects instructor names visible on the current page. When Cal Poly SLO is selected, names are checked against PolyRatings and Rate My Professors. Every other selected school uses Rate My Professors only. Quick Rate routes a click to an exact same-school RMP rating page when one safe match can be verified, and professors can be organized into browser-local albums.

## What works now

- Detects professor names and course codes from common instructor labels, PeopleSoft fields, and Cal Poly's current registration grid.
- Scans permitted embedded registration frames while keeping a single panel in the top page.
- Downloads and caches the PolyRatings index only while Cal Poly SLO is selected.
- Shows live ratings, review counts, material clarity, support for student difficulties, tags, and every available PolyRatings written review in an inline scroll area.
- Highlights matched professor names directly on the webpage with their PolyRatings score.
- Rescans dynamic course results after the page changes.
- Provides manual professor search when a portal abbreviates or hides a name.
- Uses PolyRatings plus RMP for Cal Poly SLO, and strictly RMP-only results for every other selected school.
- Checks detected professor names against the selected non-Cal Poly RMP campus instead of displaying unrelated PolyRatings profiles.
- Shows the verified RMP profile's 0–5 rating, rating count, difficulty, would-take-again percentage, and profile/rating links without mixing its scale with PolyRatings' 0–4 scale.
- Keeps the school chooser visible in the main results view as well as Quick Rate.
- Recognizes official `berkeley.edu` pages as UC Berkeley and official `calpoly.edu` pages as Cal Poly; other sites start with Cal Poly SLO and let the student choose a different exact campus.
- Replaces the former **Compare** navigation item with **Quick Rate**.
- Shows every detected or manually entered professor in Quick Rate, even when the person has no PolyRatings profile.
- Searches RMP schools, shows the campus name and location, and remembers the student's explicit choice separately for each portal origin.
- On click, checks Rate My Professors for one exact name at the selected school and opens `add/professor-rating/<profile-id>`.
- Rejects same-name results at other schools and refuses to guess if the match is missing or ambiguous.
- Offers a normal school-scoped RMP search link when an exact profile cannot be verified.
- Saves professors from PolyRatings results, verified RMP results, or Quick Rate into one or more albums.
- Creates, renames, expands, and deletes albums for a class, semester, or other shortlist.
- Lets the student edit a professor's album memberships or remove the professor from one album without affecting other albums.
- Stores albums locally in the current Chrome profile and refreshes the Saved view when another tab changes them.
- Lets the panel be dragged by its title bar, resized from its lower-right corner, maximized, and restored.

Quick Rate is a navigation handoff, not a publishing integration. The student writes, reviews, and submits the rating on Rate My Professors. The extension does not autofill or submit a rating, store Rate My Professors credentials, or claim that anything has been published.

To find the direct route and summary, the extension reads school, professor, and public summary fields embedded in RMP's normal search pages after a user searches for a professor or clicks Quick Rate. It does not download, display, or store written RMP reviews. Reddit remains link-only in this version.

## Test it in Chrome

1. Open `chrome://extensions` in Chrome.
2. Turn on **Developer mode** in the upper-right corner.
3. Click **Load unpacked**.
4. Select this `professor-insights` folder.
5. Pin **Professor Insights** from Chrome's Extensions menu if you want it to stay visible.
6. Open a Student Center or class-search page and expand the course results until instructor names are visible. Chrome blocks injection into internal pages such as `chrome://extensions`.
7. Click the Professor Insights toolbar icon. The first time, Chrome may ask for access to `cmsweb.pscs.calpoly.edu`; choose **Allow** so the detector can read the embedded PeopleSoft results frame. The extension does not request access to every website.
8. Confirm the school shown above the results. Cal Poly SLO is the default on unrecognized sites. Choose another exact campus to switch the extension to RMP-only mode; PolyRatings cards and requests should disappear.
9. Search for a professor. The main results should show an RMP profile card even when no PolyRatings profile exists. RMP uses a five-point scale; PolyRatings uses a four-point scale and appears only for Cal Poly SLO.
10. Select **Quick Rate**, then click a professor. When RMP has one exact match at the selected school, Chrome should open that professor's direct RMP rating form. Verify the name and school before entering anything.
11. If the extension cannot verify one exact same-school match, confirm that it stays put and displays a **Search RMP manually** fallback instead of opening a possibly wrong profile.
12. Click **Save** beside a professor, create an album such as **Fall 2026** or **CS 61B**, select it, and click **Save changes**.
13. Open **Saved** to expand the album. Try **Rename**, **Edit albums**, **Remove**, and **Delete** to confirm each change persists after closing and reopening the panel.
14. With Cal Poly selected, open a PolyRatings professor card and scroll through the full inline written-review list.
15. Drag the title bar, resize from the lower-right corner, then use the square title-bar button to maximize and restore the panel.

If the page uses an unexpected name format, use the search box with the professor's full first and last name. The refresh icon forces a new page scan and data download.

After editing the files, return to `chrome://extensions`, click the extension's **Reload** button, refresh the webpage, and open the panel again.

## Files

- `manifest.json` — minimal Manifest V3 configuration
- `background.js` — toggles the panel, retrieves/caches PolyRatings data, matches names, and loads review details
- `content.js` — renders the interface, switches review sources, displays inline reviews, and handles window interactions
- `detector.js` — scans the top document and permitted child frames for instructor/course context
- `quick-rate.js` — parses RMP school/professor search responses and accepts only a unique exact match at the selected campus
- `albums.js` — validates, deduplicates, and updates the versioned local album library
- `preview.html` — optional static visual preview; its sample data is not used by the installed extension

## Current permissions

- `activeTab` lets the extension act only on the tab where you click it.
- `scripting` lets it insert the panel into that tab.
- `storage` caches the PolyRatings index, remembers the selected RMP school, and keeps album names plus saved professor snapshots. Recognized official university subdomains share their campus choice; unknown sites keep it per origin. Albums remain in this Chrome profile and are not synced to an extension account.
- Access to `api-prod.polyratings.org` retrieves live ratings and all available review details only when Cal Poly SLO is selected.
- Access to the PolyRatings GitHub data repository provides a read-only fallback if the API is temporarily unavailable.
- Access to `www.ratemyprofessors.com` lets a user click resolve the professor's exact profile ID and open RMP's direct rating page.
- Optional access to `cmsweb.pscs.calpoly.edu` lets the detector read the PeopleSoft iframe only after the user grants it.

The extension does not request access to every website. Extracted portal text is reduced to possible instructor names and course codes. With Cal Poly selected, those names are matched against the locally cached PolyRatings index. With another school selected, up to 12 detected names are placed into separate normal RMP search URLs with the selected campus so exact profiles can be verified. No complete portal page or student record is sent to either review source.

## Data source and limitations

PolyRatings exposes a public API and an open daily data repository intended in part for student projects:

- <https://polyratings.dev>
- <https://github.com/Polyratings/polyratings>
- <https://github.com/Polyratings/polyratings-data>

PolyRatings uses a 0–4 rating scale, so the extension labels it explicitly rather than converting it to five stars. Ratings are community submitted and should not be presented as objective evaluations.

Portal HTML can change. The detector currently recognizes common instructor labels, current Cal Poly Material UI grids, responsive instructor fields, and legacy PeopleSoft identifiers, with manual search as a fallback. It aggregates permitted iframe results into one panel. Cross-origin frames at other schools may need their own optional host permission and adapter, so validate detection against each registration screen before distributing it.

RMP does not publish a supported public API for this flow. Its embedded search-page format can change, and its current [Terms of Use](https://www.ratemyprofessors.com/terms-of-use) restrict automated access. Treat this as a local prototype; obtain RMP permission or a supported partner API before a production or Chrome Web Store release.

## Regression tests

Run the dependency-free test suites from this folder:

```powershell
node --test .\tests\*.test.mjs
```

The fixtures contain no real student data. Detection coverage includes classic PeopleSoft, the current Cal Poly grid, multiple instructors, ARIA-only labels, and child-frame injection. Source-gating tests verify that non-Cal Poly schools never contact PolyRatings, while detected names resolve only to exact same-school RMP profiles. Review coverage verifies that all PolyRatings comments are returned newest-first, sanitized, and cached. Album coverage includes create/rename/delete, save/remove/move, source deduplication, storage normalization, bounds, and round trips. The student always performs the final Rate My Professors submission.
